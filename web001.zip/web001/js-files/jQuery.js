const  swiper = new swiper ('.swiper', {
    loop: true,

    pagination: {
        el: '.swiper-pagination',
    },

    navigation: {
        nextEl: '.swiper-button-next',
        nextEl: '.swiper-button-prev',
    },
});