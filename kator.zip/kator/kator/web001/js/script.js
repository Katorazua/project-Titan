document.addEventListener("DOMContentLoaded",
		function (event) {

function nav (event) {
	var = nav
	document.getElementById("nav-list").value;
}


document.querySelector("button")
addEventListener("clik", nav);	
		}
 );