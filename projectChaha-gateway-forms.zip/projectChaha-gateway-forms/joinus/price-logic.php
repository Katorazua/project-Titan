<?php
require 'config/database.php';
// get price form data if price button was clicked
if (isset($_POST['submit'])) {
    $firstname = filter_var($_POST['firstname'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $lastname = filter_var($_POST['lastname'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $phone = filter_var($_POST['phone'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $ref_code = filter_var($_POST['ref_code'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $gender = filter_var($_POST['gender'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $designation = filter_var($_POST['designation'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $degrees = filter_var($_POST['degrees'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $department = filter_var($_POST['department'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $specialist = filter_var($_POST['specialist'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $service_place = filter_var($_POST['service_place'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $dob = filter_var($_POST['dob'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $place_of_birth = filter_var($_POST['place_of_birth'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $blood_group = filter_var($_POST['blood_group'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $addr = filter_var($_POST['addr'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $nin = filter_var($_POST['nin'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $experience = filter_var($_POST['experience'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $doc_pricing = filter_var($_POST['doc_pricing'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $admin_pricing = filter_var($_POST['admin_pricing'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $avatar = $_FILES['avatar'];
    $scan_nin = $_FILES['scan_nin'];
    $scan_id = $_FILES['scan_id'];
    
    // check if user name or email already exist in datagase
    $user_check_query = "SELECT * FROM ahms_pricing WHERE email = '$email'";
    $user_check_result = mysqli_query($connection, $user_check_query);

    if (mysqli_num_rows($user_check_result) > 0) {
        $_SESSION['price'] = "Email already exist, please use another email address or renew your plan.";
    }

    if ($avatar['name']) {
         // Work on avater, rename avatar
         $time = time();  //make each image name unique using current timestamp
         $avatar_name = $time . $avatar['name'];
         $avatar_tmp_name = $avatar['tmp_name'];
         $avatar_detination_path = '../images/' . $avatar_name;

         // make sure file is an image
         $allowed_files = ['png', 'jpg', 'jpeg'];
         $extention = explode('.', $avatar_name);
         $extention = end($extention);
         if (in_array($extention, $allowed_files)) {
             // make sure image is not larger than 1mb+
             if ($avatar['size'] < 1000000) {
                 // upload avatar
                 move_uploaded_file($avatar_tmp_name, $avatar_detination_path);
             } else {
                 $_SESSION['price'] = "File size too big. shoul be lass than 1mb";
             }
         } else {
             $_SESSION['price'] = "File should be png, jpg, jpeg";
         }
    }

    if ($scan_nin['name']) {
         // Work on scan_nin
         $time = time();  //make each image name unique using current timestamp
         $scan_nin_name = $time . $scan_nin['name'];
         $scan_nin_tmp_name = $scan_nin['tmp_name'];
         $scan_nin_detination_path = '../images/' . $scan_nin_name;

         // make sure file is an image
         $allowed_files = ['png', 'jpg', 'jpeg'];
         $extention = explode('.', $scan_nin_name);
         $extention = end($extention);
         if (in_array($extention, $allowed_files)) {
             // make sure image is not larger than 1mb+
             if ($scan_nin['size'] < 1000000) {
                 // upload scan_nin
                 move_uploaded_file($scan_nin_tmp_name, $scan_nin_detination_path);
             } else {
                 $_SESSION['price'] = "File size too big. shoul be lass than 1mb";
             }
         } else {
             $_SESSION['price'] = "File should be png, jpg, jpeg";
         }
    }

    if ($scan_id['name']) {
         // Work on scan_id
         $time = time();  //make each image name unique using current timestamp
         $scan_id_name = $time . $scan_id['name'];
         $scan_id_tmp_name = $scan_id['tmp_name'];
         $scan_id_detination_path = '../images/' . $scan_id_name;

         // make sure file is an image
         $allowed_files = ['png', 'jpg', 'jpeg'];
         $extention = explode('.', $scan_id_name);
         $extention = end($extention);
         if (in_array($extention, $allowed_files)) {
             // make sure image is not larger than 1mb+
             if ($scan_id['size'] < 1000000) {
                 // upload scan_id
                 move_uploaded_file($scan_id_tmp_name, $scan_id_detination_path);
             } else {
                 $_SESSION['price'] = "File size too big. shoul be lass than 1mb";
             }
         } else {
             $_SESSION['price'] = "File should be png, jpg, jpeg";
         }
    }
    
    // redirect back to price page if there was any problem
    if (isset($_SESSION['price'])) {
        // pass form data back to price page
        $_SESSION['price-data'] = $_POST;
        header('location: price.php');
        die();
    } else {
        // insert new user into pricing table
        $user_query = " INSERT INTO ahms_pricing (firstname, lastname, ref_code, email, phone, department, degrees, gender, job, specialist, service_place, dob, place_of_birth, blood_group, addr, nin, about, doc_pricing, avatar, scan_nin, scan_id, admin_pricing) VALUES('$firstname', '$lastname', '$ref_code', '$email', '$phone', '$department', '$degrees', ' $gender', '$designation', '$specialist', '$service_place', '$dob', '$place_of_birth', '$blood_group', '$addr', '$nin', '$experience', '$doc_pricing', '$avatar_name', '$scan_nin_name', '$scan_id_name', '$admin_pricing')";
        $user_result = mysqli_query($connection, $user_query);
        if (!mysqli_errno($connection)) {
            // redirect to login page with success message
            $_SESSION['price-success'] = "Registration successful. Account verification, 7 working days";
            header('location: pricing.php');
            die();
        }
    }

} 