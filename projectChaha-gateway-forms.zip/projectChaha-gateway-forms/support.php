<?php 
include 'config/database.php';

if (isset($_POST['submit'])) {
  // get signup form data if signup button was clicked
    $name = filter_var($_POST['name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $phone = filter_var($_POST['phone'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $amount = filter_var($_POST['amount'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $ref_pin = filter_var($_POST['ref_pin'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $comment = filter_var($_POST['comment'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);

if (!$name){
    $_SESSION['add-user'] = "please enter Your Name In Full";
} elseif (!$email) {
    $_SESSION['add-user'] = "please enter Your Email";
} elseif (!$phone) {
    $_SESSION['add-user'] = "please enter Your Phone Number";
} elseif (!$amount) {
    $_SESSION['add-user'] = "please enter Any Amount of Choise";
} elseif (!$comment){
    $_SESSION['add-user'] = "please write Your comment";
    
  } else {

    // redirect back to add-patient page if there was any problem
    if (isset($_SESSION['add-user'])) {
        // pass form data back to add-user page
        $_SESSION['add-user-data'] = $_POST;
        header('location:' .ROOT_URL. 'index.php#support');
        die();
    } else {
        // insert new user into doctor-transfer table
        $user_query = " INSERT INTO  support (name, email, phone, amount, ref_pin, comment) VALUES('$name', '$emal', '$phone', '$amount', '$ref_pin', '$comment')";

        $user_result = mysqli_query($connection, $user_query);

        // check for error conection
        if (mysqli_errno($connection)) {
            $_SESSION['add-user'] = "User's connection fialed";
        } else {
            $_SESSION['add-user-success'] = "Thank you $name, your Aid recived successfully.";
            header('location:' .ROOT_URL. 'index.php#support');
            die();
        }
    }
  }
  
} else {
    header('location:' .ROOT_URL. 'index.php#support');
    die();
}