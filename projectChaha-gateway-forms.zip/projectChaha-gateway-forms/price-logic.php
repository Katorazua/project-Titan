<?php
require 'config/database.php';
// get price form data if price button was clicked
if (isset($_POST['submit'])) {
    $firstname = filter_var($_POST['firstname'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $lastname = filter_var($_POST['lastname'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $phone = filter_var($_POST['phone'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $ref_code = filter_var($_POST['ref_code'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $amount = filter_var($_POST['amount'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    
    // User validate input value
    if (!$firstname){
        $_SESSION['price'] = "please enter your first name";
    } elseif (!$lastname) {
        $_SESSION['price'] = "please enter your last name";
    } elseif (!$email) {
        $_SESSION['price'] = "please enter a valied email";
    } elseif (!$phone) {
        $_SESSION['price'] = "please enter a Phone Number"; 
    } else {
        // check if user name or email already exist in datagase
        $user_check_query = "SELECT * FROM pricing WHERE firstname='$firstname' AND lastname='$lastname' OR email = '$email'";
        $user_check_result = mysqli_query($connection, $user_check_query);

        if (mysqli_num_rows($user_check_result) > 0) {
            $_SESSION['price'] = "user's name or email already exist, please renew plan!";
        } 
    }  
    
    // redirect back to price page if there was any problem
    if (isset($_SESSION['price'])) {
        // pass form data back to price page
        $_SESSION['price-data'] = $_POST;
        header('location:' . ROOT_URL. 'price.php');
        die();
    } else {
        // insert new user into pricing table
        $user_query = " INSERT INTO pricing (firstname, lastname, ref_code, email, phone, amount) VALUES('$firstname', '$lastname', '$ref_code', '$email', '$phone', '$amount')";
        $user_result = mysqli_query($connection, $user_query);
        if (!mysqli_errno($connection)) {
            // redirect to login page with success message
            $_SESSION['price-success'] = "Registration successful.";
            header('location:' . ROOT_URL . 'pricing.php');
            die();
        }
    }

} 